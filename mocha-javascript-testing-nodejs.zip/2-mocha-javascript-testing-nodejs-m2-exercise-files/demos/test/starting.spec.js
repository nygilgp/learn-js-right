var assert = require('assert');

describe('Basic Mocha Test', function () {
    it('should throw errors', function () {
        

    })
});